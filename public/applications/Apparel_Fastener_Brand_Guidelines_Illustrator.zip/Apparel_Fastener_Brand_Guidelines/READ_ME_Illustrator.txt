APPAREL FASTENER - BRAND GUIDELINES (A3, 44 artboards)

1. INSTALL THE FONTS FIRST
   Install every file in Fonts/Montserrat and Fonts/Poppins, then restart Illustrator.
   Montserrat = headings, Poppins = body text. Both are free (SIL Open Font License).

2. OPEN IN ILLUSTRATOR
   Option A - All artboards in one document:
     File > Open > Apparel_Fastener_Brand_Guidelines_A3.pdf
     In the "Import PDF" dialog choose "All pages" (available in recent Illustrator versions; if you do not see it, use Option B).
     Every page becomes its own A3 artboard.
   Option B - One artboard at a time:
     Open any file in the Artboards folder (one A3 page each).

3. EDITING TIPS
   - Text is live and editable. Text with letter-spacing may import as separate
     text pieces; select and retype into one text box if you need to rewrite it.
   - Shapes and logos are editable vectors. Most items sit inside clipping groups:
     use Object > Clipping Mask > Release, or double-click to enter isolation mode.
   - Soft shadows on mockups import as images.
   - Clean vector logo files (navy and white) are in the Logo folder.

COLOURS
   AF Navy   #144467  RGB 20 68 103   CMYK 95 68 30 20 (approx.)
   Deep Navy #0B2A42  RGB 11 42 66    CMYK 95 75 40 50 (approx.)
   Mist      #EEF2F4  RGB 238 242 244 CMYK 6 2 1 0
   White     #FFFFFF
