APPAREL FASTENER - BRAND GUIDELINES (A3, 47 artboards)

1. INSTALL THE FONTS FIRST
   Install every file in Fonts/Montserrat and Fonts/Poppins, then restart Illustrator.
   Montserrat = headings, Poppins = body text. Both are free (SIL Open Font License).

2. OPEN IN ILLUSTRATOR
   Option A - All artboards in one document:
     File > Open > Apparel_Fastener_Brand_Guidelines_A3.pdf
     In the "Import PDF" dialog choose "All pages" (available in recent Illustrator versions; if you do not see it, use Option B).
     Every page becomes its own A3 artboard.
   Option B - One artboard at a time:
     Open any file in the Artboards folder (one A3 page each).

3. EDITING TIPS
   - Text is live and editable. Text with letter-spacing may import as separate
     text pieces; select and retype into one text box if you need to rewrite it.
   - Shapes and logos are editable vectors. Most items sit inside clipping groups:
     use Object > Clipping Mask > Release, or double-click to enter isolation mode.
   - Soft shadows on mockups import as images.
   - Clean vector logo files (navy and white) are in the Logo folder.

IMAGES
   The Images folder holds the final photographs used in the guidelines, with the
   AF emblem already applied to the products. Use them to replace or relink photos.

COLOURS (Pantone)
   AF Navy    PANTONE 7694 C   | Textile: 19-4120 TCX Blue Opal    | CMYK 95 68 30 20
   Deep Navy  PANTONE 2965 C   | Textile: 19-4111 TCX Pageant Blue | CMYK 95 75 40 50
   Mist       PANTONE 7694 C at 7% tint                          | CMYK 6 2 1 0
   White      Paper white / no ink | Textile: 11-0601 TCX Bright White

   Swatches: in Illustrator open the Swatches panel > menu > Open Swatch Library >
   Other Library... and choose AF_Brand_Colours.ase. 7694 C and 2965 C load as spot colours.
   Always check against a physical Pantone guide before production.
