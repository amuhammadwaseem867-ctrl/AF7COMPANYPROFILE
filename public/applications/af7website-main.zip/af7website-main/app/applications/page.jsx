"use client";

import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import "./applications.css";

const applications = [
  {
    number: "01",
    title: "Fashion",
    text: "Refined fastening solutions for contemporary fashion, premium garments and design-led apparel.",
  },
  {
    number: "02",
    title: "Activewear",
    text: "Performance-focused components developed for active, sports and lifestyle apparel.",
  },
  {
    number: "03",
    title: "Outerwear",
    text: "Reliable zipper and fastening solutions for jackets, coats, outdoor garments and layered apparel.",
  },
  {
    number: "04",
    title: "Lifestyle",
    text: "Versatile fastening details designed for everyday garments with a focus on function and finish.",
  },
];

export default function ApplicationsPage() {
  return (
    <>
      <Navbar />

      <main className="applications-page">
        <section className="applications-hero">
          <div className="applications-hero-inner">
            <motion.div
              className="applications-eyebrow"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <span>AF7 / APPLICATIONS</span>
              <span className="applications-eyebrow-line" />
              <span>APPAREL FASTENER GROUP</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 45 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.9,
                delay: 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              DESIGNED FOR
              <br />
              <span>EVERY MOVEMENT.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.7,
                delay: 0.3,
              }}
            >
              AF7 develops fastening solutions for the evolving
              world of apparel — combining precision, performance
              and thoughtful design across a range of garment
              applications.
            </motion.p>
          </div>
        </section>

        <section className="applications-content">
          <div className="applications-content-header">
            <span>01 — APPLICATION AREAS</span>

            <p>
              From fashion and activewear to outerwear and
              lifestyle garments, AF7 solutions are designed
              to become an integral part of the garment.
            </p>
          </div>

          <div className="applications-list">
            {applications.map((application, index) => (
              <motion.a
                href="/products"
                className="application-row"
                key={application.number}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{
                  once: true,
                  amount: 0.2,
                }}
                transition={{
                  duration: 0.6,
                  delay: index * 0.08,
                }}
              >
                <span className="application-row-number">
                  {application.number}
                </span>

                <h2>{application.title}</h2>

                <p>{application.text}</p>

                <span className="application-row-arrow">
                  <ArrowUpRight
                    size={19}
                    strokeWidth={1.2}
                  />
                </span>
              </motion.a>
            ))}
          </div>
        </section>

        <section className="applications-detail">
          <div className="applications-detail-intro">
            <span>02 — BUILT AROUND THE GARMENT</span>
          </div>

          <div className="applications-detail-content">
            <h2>
              FUNCTION
              <br />
              <span>MEETS FORM.</span>
            </h2>

            <p>
              A fastening system is more than a functional
              component. It contributes to the way a garment
              opens, closes, moves and feels. AF7 focuses on
              creating solutions that work naturally with the
              construction and visual language of modern apparel.
            </p>
          </div>
        </section>

        <section className="applications-capabilities">
          <div className="applications-capabilities-header">
            <span>03 — AF7 APPROACH</span>

            <h2>
              FROM DETAIL
              <br />
              <span>TO PERFORMANCE.</span>
            </h2>
          </div>

          <div className="applications-capabilities-grid">
            <div className="application-capability">
              <span>01</span>
              <h3>Precision</h3>
              <p>
                Consistent construction and attention to detail
                across fastening components and garment applications.
              </p>
            </div>

            <div className="application-capability">
              <span>02</span>
              <h3>Performance</h3>
              <p>
                Reliable fastening solutions designed to support
                the functional demands of contemporary apparel.
              </p>
            </div>

            <div className="application-capability">
              <span>03</span>
              <h3>Design</h3>
              <p>
                Clean and considered components that complement
                the visual identity and construction of each garment.
              </p>
            </div>
          </div>
        </section>

        <section className="applications-cta">
          <div>
            <span>AF7 / CUSTOM REQUIREMENTS</span>

            <h2>
              HAVE A
              <br />
              <span>PROJECT IN MIND?</span>
            </h2>
          </div>

          <a href="/contact">
            <span>Discuss your requirements</span>
            <ArrowUpRight
              size={18}
              strokeWidth={1.2}
            />
          </a>
        </section>
      </main>

      <Footer />
    </>
  );
}