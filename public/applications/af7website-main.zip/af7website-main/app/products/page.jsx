import Navbar from "@/components/Navbar";
import ProductGrid from "@/components/ProductGrid";
import Footer from "@/components/Footer";

export default function ProductsPage() {
  return (
    <>
      <Navbar />

      <main>
        <ProductGrid />
      </main>

      <Footer />
    </>
  );
}