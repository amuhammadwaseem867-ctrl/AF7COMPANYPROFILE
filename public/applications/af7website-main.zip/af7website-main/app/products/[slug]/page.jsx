import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import products from "@/data/products";
import "./product-detail.css";

export default async function ProductDetailPage({ params }) {
  const { slug } = await params;

  const product = products.find(
    (item) => item.href === `/products/${slug}`
  );

  if (!product) {
    return (
      <>
        <Navbar />

        <main className="product-not-found">
          <span>AF7 / 404</span>

          <h1>PRODUCT NOT FOUND.</h1>

          <a href="/products">Back to catalogue</a>
        </main>

        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar />

      <main className="product-detail">
        <section className="product-detail-hero">
          <div className="product-detail-image">
            <div
              className="product-detail-image-bg"
              style={{
                backgroundImage: `url("${product.image}")`,
              }}
            />

            <div className="product-detail-image-overlay" />

            <div className="product-detail-image-meta">
              <span>AF7</span>

              <span>
                PRODUCT / {product.category.toUpperCase()}
              </span>
            </div>

            <div className="product-detail-number">
              {String(
                products.findIndex(
                  (item) => item.id === product.id
                ) + 1
              ).padStart(2, "0")}
            </div>
          </div>

          <div className="product-detail-content">
            <div className="product-detail-top">
              <span>{product.category}</span>
              <span>{product.subcategory}</span>
            </div>

            <div className="product-detail-heading">
              <span className="product-detail-label">
                AF7 / PRODUCT
              </span>

              <h1>{product.name}</h1>

              <p>{product.description}</p>
            </div>

            <div className="product-detail-info">
              <div className="product-info-row">
                <span>Category</span>
                <strong>{product.category}</strong>
              </div>

              <div className="product-info-row">
                <span>Type</span>
                <strong>{product.subcategory}</strong>
              </div>

              <div className="product-info-row">
                <span>Application</span>
                <strong>Apparel & Garment</strong>
              </div>

              <div className="product-info-row">
                <span>Development</span>
                <strong>AF7 Solutions</strong>
              </div>
            </div>

            <a
              href="/contact"
              className="product-detail-cta"
            >
              <span>Request information</span>
              <span className="product-detail-cta-arrow">
                ↗
              </span>
            </a>
          </div>
        </section>

        <section className="product-detail-bottom">
          <div className="product-detail-bottom-label">
            <span>AF7 / APPLICATION</span>
          </div>

          <div className="product-detail-bottom-copy">
            <h2>
              ENGINEERED FOR
              <br />
              <span>THE GARMENT.</span>
            </h2>

            <p>
              AF7 fastening solutions are presented with a focus
              on precision, dependable performance and refined
              garment integration. Product development can be
              adapted around individual design and application
              requirements.
            </p>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}