"use client";

import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import "./sustainability.css";

const principles = [
  {
    number: "01",
    title: "Sustainable Manufacturing",
    text: "We seek to reduce waste and energy use while supporting more responsible materials and packaging throughout production.",
  },
  {
    number: "02",
    title: "Ethical Sourcing",
    text: "We value responsible supply-chain relationships built around ethical practices, fair labour conditions and responsible sourcing.",
  },
  {
    number: "03",
    title: "Continuous Improvement",
    text: "Sustainability is an ongoing process. We continue to evaluate materials, production and processes for opportunities to improve.",
  },
];

export default function SustainabilityPage() {
  return (
    <>
      <Navbar />

      <main className="sustainability-page">
        <section className="sustainability-hero">
          <div className="sustainability-hero-inner">
            <motion.div
              className="sustainability-eyebrow"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <span>AF7 / SUSTAINABILITY</span>
              <span className="sustainability-eyebrow-line" />
              <span>RESPONSIBLE BY DESIGN</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 45 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.9,
                delay: 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              BETTER
              <br />
              <span>BY DESIGN.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.7,
                delay: 0.3,
              }}
            >
              AF7 believes performance and responsibility can
              move together. Our approach considers materials,
              manufacturing, sourcing and the long-term impact
              of every decision.
            </motion.p>
          </div>
        </section>

        <section className="sustainability-intro">
          <div className="sustainability-intro-label">
            <span>01 — OUR APPROACH</span>
          </div>

          <div className="sustainability-intro-content">
            <h2>
              RESPONSIBILITY
              <br />
              <span>IN EVERY DETAIL.</span>
            </h2>

            <p>
              As a zipper and fastening brand, AF7 understands
              that even the smallest component contributes to
              the life and character of a garment. We focus on
              responsible practices that support quality,
              durability and more thoughtful production.
            </p>
          </div>
        </section>

        <section className="sustainability-principles">
          <div className="sustainability-section-header">
            <span>02 — SUSTAINABILITY PRINCIPLES</span>

            <p>
              Our sustainability approach is built around
              practical improvements across manufacturing,
              sourcing and product development.
            </p>
          </div>

          <div className="sustainability-principles-list">
            {principles.map((item, index) => (
              <motion.div
                className="sustainability-principle"
                key={item.number}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{
                  once: true,
                  amount: 0.2,
                }}
                transition={{
                  duration: 0.6,
                  delay: index * 0.08,
                }}
              >
                <span className="sustainability-number">
                  {item.number}
                </span>

                <h3>{item.title}</h3>

                <p>{item.text}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="sustainability-manufacturing">
          <div className="sustainability-manufacturing-image">
            <div className="sustainability-image-overlay" />
            <span>AF7 / PRODUCTION</span>
          </div>

          <div className="sustainability-manufacturing-content">
            <span className="sustainability-small-label">
              03 — RESPONSIBLE MANUFACTURING
            </span>

            <h2>
              BUILT WITH
              <br />
              <span>PURPOSE.</span>
            </h2>

            <p>
              AF7 works toward more responsible manufacturing
              through consideration of materials, packaging,
              energy use and waste reduction. Our production
              approach is focused on creating high-quality
              fastening solutions while continually identifying
              opportunities for improvement.
            </p>

            <a href="/contact">
              <span>Talk to AF7</span>
              <ArrowUpRight
                size={17}
                strokeWidth={1.2}
              />
            </a>
          </div>
        </section>

        <section className="sustainability-ethics">
          <div className="sustainability-ethics-label">
            <span>04 — ETHICAL SOURCING</span>
          </div>

          <div className="sustainability-ethics-content">
            <h2>
              PEOPLE
              <br />
              <span>MATTER.</span>
            </h2>

            <p>
              Responsible production extends beyond the product.
              AF7 values supply-chain relationships that support
              ethical practices, fair labour conditions and
              responsible sourcing.
            </p>

            <div className="sustainability-ethics-line">
              <span>ETHICAL PRACTICES</span>
              <span>FAIR LABOUR</span>
              <span>RESPONSIBLE SOURCING</span>
            </div>
          </div>
        </section>

        <section className="sustainability-cta">
          <div>
            <span>AF7 / THE NEXT STEP</span>

            <h2>
              BUILD
              <br />
              <span>BETTER.</span>
            </h2>
          </div>

          <a href="/contact">
            <span>Discuss your requirements</span>
            <ArrowUpRight
              size={18}
              strokeWidth={1.2}
            />
          </a>
        </section>
      </main>

      <Footer />
    </>
  );
}