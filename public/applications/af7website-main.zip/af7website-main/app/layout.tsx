import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AF7 | Apparel Fastener Group",
  description:
    "AF7 develops high-performance zipper and fastening solutions for modern apparel, fashion and activewear.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}