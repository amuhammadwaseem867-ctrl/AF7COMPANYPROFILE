"use client";

import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import "./about.css";

const values = [
  {
    number: "01",
    title: "Innovation",
    text: "We continuously explore better ideas, technologies and approaches to fastening solutions.",
  },
  {
    number: "02",
    title: "Quality",
    text: "Precision, consistency and dependable performance remain central to every AF7 solution.",
  },
  {
    number: "03",
    title: "Sustainability",
    text: "We pursue more responsible materials, manufacturing practices and long-term product thinking.",
  },
];

export default function AboutPage() {
  return (
    <>
      <Navbar />

      <main className="about-page">
        <section className="about-hero">
          <div className="about-hero-inner">
            <motion.div
              className="about-eyebrow"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <span>AF7 / ABOUT</span>
              <span className="about-eyebrow-line" />
              <span>APPAREL FASTENER GROUP</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 45 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.9,
                delay: 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              THE DETAIL
              <br />
              <span>MATTERS.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
            >
              AF7 is a Hong Kong-based zipper brand founded by
              Apparel Fastener Group, creating high-quality
              fastening solutions for the evolving world of apparel.
            </motion.p>
          </div>
        </section>

        <section className="about-intro">
          <div className="about-intro-label">
            <span>01 — WHO WE ARE</span>
          </div>

          <div className="about-intro-content">
            <h2>
              ENGINEERED FOR
              <br />
              <span>MODERN APPAREL.</span>
            </h2>

            <div className="about-intro-copy">
              <p>
                AF7 combines cutting-edge technology with
                thoughtful design to develop fastening solutions
                built around the needs of manufacturers,
                designers and retailers.
              </p>

              <p>
                With a production facility in Lahore and a
                global outlook from Hong Kong, AF7 focuses on
                delivering dependable solutions that enhance
                the durability, functionality and visual character
                of garments.
              </p>
            </div>
          </div>
        </section>

        <section className="about-global">
          <div className="about-global-image">
            <div className="about-global-overlay" />

            <div className="about-global-image-meta">
              <span>AF7 / GLOBAL PRESENCE</span>
              <span>HONG KONG · LAHORE</span>
            </div>
          </div>

          <div className="about-global-content">
            <span>02 — OUR PRESENCE</span>

            <h2>
              FROM
              <br />
              <span>ASIA TO THE WORLD.</span>
            </h2>

            <p>
              AF7 operates with an international perspective,
              connecting brand development, manufacturing and
              apparel requirements across markets.
            </p>

            <div className="about-location-list">
              <div>
                <span>01</span>
                <strong>HONG KONG</strong>
              </div>

              <div>
                <span>02</span>
                <strong>LAHORE</strong>
              </div>
            </div>
          </div>
        </section>

        <section className="about-values">
          <div className="about-values-header">
            <span>03 — CORE VALUES</span>

            <h2>
              WHAT
              <br />
              <span>DRIVES US.</span>
            </h2>
          </div>

          <div className="about-values-list">
            {values.map((value, index) => (
              <motion.div
                className="about-value"
                key={value.number}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{
                  duration: 0.6,
                  delay: index * 0.08,
                }}
              >
                <span className="about-value-number">
                  {value.number}
                </span>

                <h3>{value.title}</h3>

                <p>{value.text}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="about-mission">
          <div className="about-mission-label">
            <span>04 — OUR MISSION</span>
          </div>

          <div className="about-mission-content">
            <h2>
              MOVE THE
              <br />
              <span>INDUSTRY FORWARD.</span>
            </h2>

            <p>
              Our mission is to create premium zipper solutions
              that combine performance, durability and
              sustainability while building lasting partnerships
              with manufacturers, designers and apparel brands.
            </p>

            <a href="/products">
              <span>Explore our solutions</span>
              <ArrowUpRight size={17} strokeWidth={1.2} />
            </a>
          </div>
        </section>

        <section className="about-cta">
          <span>AF7 / THE FUTURE OF FASTENING</span>

          <h2>
            BUILT FOR
            <br />
            <span>WHAT'S NEXT.</span>
          </h2>

          <a href="/contact">
            <span>Start a conversation</span>
            <ArrowUpRight size={18} strokeWidth={1.2} />
          </a>
        </section>
      </main>

      <Footer />
    </>
  );
}