"use client";

import { motion } from "motion/react";
import { ArrowUpRight, Mail, MapPin, Phone } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import "./contact.css";

const contactDetails = [
  {
    icon: Mail,
    label: "Email",
    value: "info@af7.com",
    href: "mailto:info@af7.com",
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+852 0000 0000",
    href: "tel:+85200000000",
  },
  {
    icon: MapPin,
    label: "Location",
    value: "Hong Kong · Lahore",
    href: "#locations",
  },
];

export default function ContactPage() {
  return (
    <>
      <Navbar />

      <main className="contact-page">
        <section className="contact-hero">
          <div className="contact-hero-inner">
            <motion.div
              className="contact-eyebrow"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <span>AF7 / CONTACT</span>
              <span className="contact-eyebrow-line" />
              <span>LET'S CONNECT</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 45 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.9,
                delay: 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              LET'S BUILD
              <br />
              <span>SOMETHING TOGETHER.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.7,
                delay: 0.3,
              }}
            >
              Tell us about your product, garment or fastening
              requirements. Our team can discuss suitable solutions
              and development possibilities.
            </motion.p>
          </div>
        </section>

        <section className="contact-main">
          <div className="contact-main-label">
            <span>01 — GET IN TOUCH</span>
          </div>

          <div className="contact-main-content">
            <div className="contact-details">
              {contactDetails.map((item, index) => {
                const Icon = item.icon;

                return (
                  <motion.a
                    href={item.href}
                    className="contact-detail"
                    key={item.label}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{
                      once: true,
                      amount: 0.2,
                    }}
                    transition={{
                      duration: 0.6,
                      delay: index * 0.08,
                    }}
                  >
                    <div className="contact-detail-icon">
                      <Icon size={17} strokeWidth={1.2} />
                    </div>

                    <div>
                      <span>{item.label}</span>
                      <strong>{item.value}</strong>
                    </div>

                    <ArrowUpRight
                      size={17}
                      strokeWidth={1.2}
                      className="contact-detail-arrow"
                    />
                  </motion.a>
                );
              })}
            </div>

            <div className="contact-form-wrap">
              <span className="contact-form-label">
                02 — YOUR REQUIREMENTS
              </span>

              <form className="contact-form">
                <div className="contact-form-row">
                  <label>
                    Name
                    <input
                      type="text"
                      name="name"
                      placeholder="Your name"
                    />
                  </label>

                  <label>
                    Company
                    <input
                      type="text"
                      name="company"
                      placeholder="Company name"
                    />
                  </label>
                </div>

                <div className="contact-form-row">
                  <label>
                    Email
                    <input
                      type="email"
                      name="email"
                      placeholder="your@email.com"
                    />
                  </label>

                  <label>
                    Phone
                    <input
                      type="tel"
                      name="phone"
                      placeholder="+00 000 000 000"
                    />
                  </label>
                </div>

                <label>
                  Project / Requirements
                  <textarea
                    name="message"
                    rows="6"
                    placeholder="Tell us about your project..."
                  />
                </label>

                <button type="submit">
                  <span>Send enquiry</span>
                  <ArrowUpRight
                    size={17}
                    strokeWidth={1.2}
                  />
                </button>
              </form>
            </div>
          </div>
        </section>

        <section className="contact-locations" id="locations">
          <div className="contact-location-label">
            <span>03 — AF7 / LOCATIONS</span>
          </div>

          <div className="contact-location-content">
            <div className="contact-location">
              <span>01</span>

              <h2>HONG KONG</h2>

              <p>
                AF7 headquarters and global business presence.
              </p>
            </div>

            <div className="contact-location">
              <span>02</span>

              <h2>LAHORE</h2>

              <p>
                State-of-the-art production facility supporting
                AF7 manufacturing operations.
              </p>
            </div>
          </div>
        </section>

        <section className="contact-cta">
          <span>AF7 / FASTENING SOLUTIONS</span>

          <h2>
            HAVE A
            <br />
            <span>PROJECT IN MIND?</span>
          </h2>

          <a href="/products">
            <span>Explore products</span>
            <ArrowUpRight
              size={18}
              strokeWidth={1.2}
            />
          </a>
        </section>
      </main>

      <Footer />
    </>
  );
}