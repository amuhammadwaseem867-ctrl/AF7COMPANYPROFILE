"use client";

import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import "./BrandStatement.css";

const qualities = [
  {
    number: "01",
    title: "Precision",
    text: "Consistent engineering and refined construction in every detail.",
  },
  {
    number: "02",
    title: "Performance",
    text: "Reliable fastening solutions built for demanding apparel applications.",
  },
  {
    number: "03",
    title: "Responsibility",
    text: "A forward-looking approach to materials, production and sustainability.",
  },
];

export default function BrandStatement() {
  return (
    <section className="brand-statement">
      <div className="brand-statement-container">

        <motion.div
          className="brand-statement-top"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.7 }}
        >
          <span className="brand-statement-label">
            AF7 / THE BRAND
          </span>

          <span className="brand-statement-line" />

          <span className="brand-statement-location">
            HONG KONG · LAHORE
          </span>
        </motion.div>


        <div className="brand-statement-main">

          <motion.div
            className="brand-statement-heading"
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8 }}
          >
            <span className="brand-small-title">
              THE DETAIL
            </span>

            <h2>
              THAT HOLDS
              <br />
              <span>EVERYTHING TOGETHER.</span>
            </h2>
          </motion.div>


          <motion.div
            className="brand-statement-copy"
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, delay: 0.15 }}
          >
            <p>
              AF7 develops advanced zipper solutions for the
              evolving world of apparel. Combining precision,
              performance and responsible thinking, we create
              fastening systems designed to become an integral
              part of the garment.
            </p>

            <a href="/about" className="brand-statement-link">
              <span>Discover AF7</span>
              <ArrowUpRight size={16} strokeWidth={1.3} />
            </a>
          </motion.div>

        </div>


        <div className="brand-qualities">

          {qualities.map((quality, index) => (
            <motion.div
              className="brand-quality"
              key={quality.number}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{
                duration: 0.6,
                delay: index * 0.1,
              }}
            >
              <div className="brand-quality-top">
                <span>{quality.number}</span>
                <span className="brand-quality-line" />
              </div>

              <h3>{quality.title}</h3>

              <p>{quality.text}</p>
            </motion.div>
          ))}

        </div>

      </div>
    </section>
  );
}