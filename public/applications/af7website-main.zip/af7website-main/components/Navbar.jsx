"use client";

import { ArrowUpRight, Menu } from "lucide-react";
import "./Navbar.css";

const links = [
  { label: "About", href: "/about" },
  { label: "Products", href: "/products" },
  { label: "Applications", href: "/applications" },
  { label: "Sustainability", href: "/sustainability" },
];

export default function Navbar() {
  return (
    <header className="navbar">
      <div className="navbar-line" />

      <div className="navbar-inner">

        <a href="/" className="af7-logo" aria-label="AF7 home">
          <span className="af7-logo-text">AF7</span>
        </a>

        <nav className="af7-navigation" aria-label="Main navigation">
          {links.map((link) => (
            <a href={link.href} key={link.href}>
              {link.label}
            </a>
          ))}
        </nav>

        <div className="af7-right">

          <a href="/contact" className="af7-contact">
            <span>Contact</span>
            <ArrowUpRight size={15} strokeWidth={1.3} />
          </a>

          <button
            className="af7-menu"
            type="button"
            aria-label="Open menu"
          >
            <Menu size={21} strokeWidth={1.2} />
          </button>

        </div>

      </div>
    </header>
  );
}