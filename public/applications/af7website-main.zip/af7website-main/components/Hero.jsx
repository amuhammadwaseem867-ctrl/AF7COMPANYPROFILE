"use client";

import { motion } from "motion/react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import "./Hero.css";

export default function Hero() {
  return (
    <section className="hero">

      {/* Background */}
      <div className="hero-image" />
      <div className="hero-overlay" />

      {/* Main Content */}
      <div className="hero-container">

        <motion.div
          className="hero-eyebrow"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <span className="hero-eyebrow-brand">AF7</span>
          <span className="hero-eyebrow-line" />
          <span>APPAREL FASTENER GROUP</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 45 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.9,
            delay: 0.1,
            ease: [0.22, 1, 0.36, 1],
          }}
        >
          ENGINEERED
          <br />
          <span>TO MOVE.</span>
        </motion.h1>

        <motion.div
          className="hero-footer-content"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.8,
            delay: 0.3,
          }}
        >
          <p>
            High-performance zipper solutions engineered
            for modern apparel, fashion and activewear.
          </p>

          <a href="/products" className="hero-explore">
            <span>Explore products</span>
            <ArrowUpRight size={17} strokeWidth={1.4} />
          </a>
        </motion.div>

      </div>

      {/* Bottom Information */}
      <div className="hero-bottom">

        <div className="hero-index">
          <span>01</span>
          <span className="hero-index-line" />
          <span>04</span>
        </div>

        <div className="hero-scroll">
          <ArrowDownRight size={15} strokeWidth={1.2} />
          <span>SCROLL TO EXPLORE</span>
        </div>

        <div className="hero-values">
          QUALITY&nbsp;&nbsp;·&nbsp;&nbsp;PERFORMANCE&nbsp;&nbsp;·&nbsp;&nbsp;SUSTAINABILITY
        </div>

      </div>

    </section>
  );
}