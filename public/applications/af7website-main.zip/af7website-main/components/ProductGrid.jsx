"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import products from "@/data/products";
import ProductCard from "@/components/ProductCard";
import "./ProductGrid.css";

const categories = [
  "All",
  "Zippers",
  "Sliders",
  "Pullers",
  "Garment Accessories",
  "Fastening Components",
  "Custom Solutions",
];

export default function ProductGrid() {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProducts = useMemo(() => {
    if (activeCategory === "All") {
      return products;
    }

    return products.filter(
      (product) => product.category === activeCategory
    );
  }, [activeCategory]);

  return (
    <section className="product-grid-section" id="products">
      <div className="product-grid-container">

        <motion.div
          className="product-grid-header"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.8 }}
        >
          <div className="product-grid-heading">
            <span className="product-grid-label">
              AF7 / PRODUCT CATALOGUE
            </span>

            <h1>
              BUILT AROUND
              <br />
              <span>THE DETAIL.</span>
            </h1>
          </div>

          <div className="product-grid-intro">
            <p>
              Explore fastening systems, components and apparel
              solutions presented through the AF7 product catalogue.
              Designed around precision, performance and contemporary
              garment applications.
            </p>

            <a href="/contact" className="product-grid-link">
              <span>Discuss your requirements</span>
              <ArrowUpRight size={16} strokeWidth={1.3} />
            </a>
          </div>
        </motion.div>

        <motion.div
          className="product-category-nav"
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={`product-category-button ${
                activeCategory === category ? "active" : ""
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </motion.div>

        <div className="product-grid-meta">
          <span>
            {activeCategory === "All"
              ? "ALL PRODUCTS"
              : activeCategory.toUpperCase()}
          </span>

          <span className="product-grid-meta-line" />

          <span>
            {String(filteredProducts.length).padStart(2, "0")} ITEMS
          </span>
        </div>

        <motion.div layout className="products-grid">
          <AnimatePresence mode="popLayout">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                layout
                initial={{ opacity: 0, y: 25 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 15 }}
                transition={{
                  duration: 0.45,
                  delay: index * 0.035,
                  ease: [0.22, 1, 0.36, 1],
                }}
              >
                <ProductCard
                  product={product}
                  index={index}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

      </div>
    </section>
  );
}