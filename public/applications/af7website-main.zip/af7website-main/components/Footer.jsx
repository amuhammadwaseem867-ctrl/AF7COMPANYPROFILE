import { ArrowUpRight } from "lucide-react";
import "./Footer.css";

const footerLinks = [
  { label: "About", href: "/about" },
  { label: "Products", href: "/products" },
  { label: "Applications", href: "/applications" },
  { label: "Sustainability", href: "/sustainability" },
  { label: "Contact", href: "/contact" },
];

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">

        <div className="footer-top">
          <a href="/" className="footer-logo">
            AF7
          </a>

          <p className="footer-description">
            High-performance fastening solutions for modern
            apparel, fashion and activewear.
          </p>

          <a href="/contact" className="footer-enquiry">
            <span>Start a conversation</span>
            <ArrowUpRight size={15} strokeWidth={1.2} />
          </a>
        </div>

        <div className="footer-columns">

          <div className="footer-column">
            <span className="footer-heading">
              NAVIGATION
            </span>

            <nav className="footer-nav">
              {footerLinks.map((link) => (
                <a href={link.href} key={link.href}>
                  {link.label}
                </a>
              ))}
            </nav>
          </div>

          <div className="footer-column">
            <span className="footer-heading">
              LOCATIONS
            </span>

            <div className="footer-location">
              <span>01</span>
              <strong>HONG KONG</strong>
            </div>

            <div className="footer-location">
              <span>02</span>
              <strong>LAHORE</strong>
            </div>
          </div>

          <div className="footer-column footer-identity">
            <span className="footer-heading">
              APPAREL FASTENER GROUP
            </span>

            <p>
              Innovation · Quality · Sustainability
            </p>
          </div>

        </div>

        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} AF7
          </span>

          <span>
            APPAREL FASTENER GROUP
          </span>

          <a href="#top">
            BACK TO TOP ↑
          </a>
        </div>

      </div>
    </footer>
  );
}