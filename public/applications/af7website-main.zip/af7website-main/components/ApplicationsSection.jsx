"use client";

import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import "./ApplicationsSection.css";

const applications = [
  {
    number: "01",
    title: "Fashion",
    text: "Refined fastening solutions for contemporary fashion and premium garment construction.",
  },
  {
    number: "02",
    title: "Activewear",
    text: "Performance-focused components designed for modern active and lifestyle apparel.",
  },
  {
    number: "03",
    title: "Outerwear",
    text: "Reliable fastening systems developed for jackets, outer layers and technical garments.",
  },
  {
    number: "04",
    title: "Lifestyle",
    text: "Versatile components created for everyday apparel with a focus on detail and finish.",
  },
];

export default function ApplicationsSection() {
  return (
    <section className="applications-section">
      <div className="applications-container">

        <motion.div
          className="applications-header"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.7 }}
        >
          <div>
            <span className="applications-label">
              AF7 / APPLICATIONS
            </span>

            <h2>
              MADE FOR
              <br />
              <span>WHAT MOVES.</span>
            </h2>
          </div>

          <p>
            From fashion and activewear to outerwear and
            lifestyle apparel, AF7 fastening solutions are
            designed to integrate naturally into the garment.
          </p>
        </motion.div>

        <div className="applications-list">
          {applications.map((item, index) => (
            <motion.a
              href="/products"
              className="application-item"
              key={item.number}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: 0.6,
                delay: index * 0.08,
              }}
            >
              <span className="application-number">
                {item.number}
              </span>

              <h3>{item.title}</h3>

              <p>{item.text}</p>

              <span className="application-arrow">
                <ArrowUpRight
                  size={18}
                  strokeWidth={1.2}
                />
              </span>
            </motion.a>
          ))}
        </div>

        <div className="applications-footer">
          <span>PRECISION / PERFORMANCE / DESIGN</span>

          <a href="/products">
            Explore catalogue
            <ArrowUpRight size={15} strokeWidth={1.2} />
          </a>
        </div>

      </div>
    </section>
  );
}