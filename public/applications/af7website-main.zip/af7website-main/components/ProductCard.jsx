"use client";

import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import "./ProductCard.css";

export default function ProductCard({ product, index = 0 }) {
  return (
    <motion.a
      href={product.href}
      className="product-card"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{
        duration: 0.65,
        delay: index * 0.05,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      <div className="product-card-image-wrap">
        <div
          className="product-card-image"
          style={{
            backgroundImage: `url("${product.image}")`,
          }}
        />

        <div className="product-card-overlay" />

        <div className="product-card-top">
          <span>
            {String(index + 1).padStart(2, "0")}
          </span>

          <span className="product-card-category">
            {product.category}
          </span>
        </div>

        <motion.div
          className="product-card-arrow"
          whileHover={{ scale: 1.05 }}
        >
          <ArrowUpRight size={18} strokeWidth={1.3} />
        </motion.div>
      </div>

      <div className="product-card-content">
        <div className="product-card-meta">
          <span>{product.subcategory}</span>
          <span>AF7</span>
        </div>

        <div className="product-card-title-row">
          <h3>{product.name}</h3>

          <span className="product-card-view">
            VIEW
          </span>
        </div>

        <p>{product.description}</p>
      </div>
    </motion.a>
  );
}