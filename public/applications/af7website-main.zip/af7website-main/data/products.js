const products = [
  // =========================================
  // ZIPPERS — 5
  // =========================================
  {
    id: "metal-zippers",
    category: "Zippers",
    subcategory: "Metal",
    name: "Metal Zippers",
    description:
      "Durable fastening solutions with a refined metal finish for premium apparel applications.",
    image:
      "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1200&q=80",
    href: "/products/metal-zippers",
  },
  {
    id: "coil-zippers",
    category: "Zippers",
    subcategory: "Coil",
    name: "Coil Zippers",
    description:
      "Flexible zipper systems designed for smooth operation and versatile garment applications.",
    image:
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1200&q=80",
    href: "/products/coil-zippers",
  },
  {
    id: "resin-zippers",
    category: "Zippers",
    subcategory: "Resin",
    name: "Resin Zippers",
    description:
      "Lightweight fastening solutions combining functional performance with a clean modern finish.",
    image:
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1200&q=80",
    href: "/products/resin-zippers",
  },
  {
    id: "invisible-zippers",
    category: "Zippers",
    subcategory: "Invisible",
    name: "Invisible Zippers",
    description:
      "Discreet fastening systems designed to integrate seamlessly into refined garment designs.",
    image:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80",
    href: "/products/invisible-zippers",
  },
  {
    id: "technical-zippers",
    category: "Zippers",
    subcategory: "Technical",
    name: "Technical Zippers",
    description:
      "Performance-oriented zipper solutions for demanding apparel and technical applications.",
    image:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1200&q=80",
    href: "/products/technical-zippers",
  },

  // =========================================
  // SLIDERS — 5
  // =========================================
  {
    id: "auto-lock-sliders",
    category: "Sliders",
    subcategory: "Auto-Lock",
    name: "Auto-Lock Sliders",
    description:
      "Precision slider systems designed for dependable locking and smooth zipper operation.",
    image:
      "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=1200&q=80",
    href: "/products/auto-lock-sliders",
  },
  {
    id: "non-lock-sliders",
    category: "Sliders",
    subcategory: "Non-Lock",
    name: "Non-Lock Sliders",
    description:
      "Smooth operating sliders developed for flexible and reliable fastening applications.",
    image:
      "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1200&q=80",
    href: "/products/non-lock-sliders",
  },
  {
    id: "reversible-sliders",
    category: "Sliders",
    subcategory: "Reversible",
    name: "Reversible Sliders",
    description:
      "Versatile slider solutions created for reversible and contemporary garment constructions.",
    image:
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1200&q=80",
    href: "/products/reversible-sliders",
  },
  {
    id: "fashion-sliders",
    category: "Sliders",
    subcategory: "Fashion",
    name: "Fashion Sliders",
    description:
      "Design-focused slider solutions that add distinctive character to modern apparel.",
    image:
      "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=1200&q=80",
    href: "/products/fashion-sliders",
  },
  {
    id: "custom-sliders",
    category: "Sliders",
    subcategory: "Custom",
    name: "Custom Sliders",
    description:
      "Custom-developed slider solutions tailored to specific garment and brand requirements.",
    image:
      "https://images.unsplash.com/photo-1506629905607-d9a6b4c7f6f2?auto=format&fit=crop&w=1200&q=80",
    href: "/products/custom-sliders",
  },

  // =========================================
  // PULLERS — 5
  // =========================================
  {
    id: "standard-pullers",
    category: "Pullers",
    subcategory: "Standard",
    name: "Standard Pullers",
    description:
      "Clean and functional puller designs for everyday garment fastening applications.",
    image:
      "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=1200&q=80",
    href: "/products/standard-pullers",
  },
  {
    id: "fashion-pullers",
    category: "Pullers",
    subcategory: "Fashion",
    name: "Fashion Pullers",
    description:
      "Distinctive puller designs created to complement contemporary fashion aesthetics.",
    image:
      "https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=1200&q=80",
    href: "/products/fashion-pullers",
  },
  {
    id: "cord-pullers",
    category: "Pullers",
    subcategory: "Cord",
    name: "Cord Pullers",
    description:
      "Functional cord-based puller solutions suited to activewear and casual garment designs.",
    image:
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=80",
    href: "/products/cord-pullers",
  },
  {
    id: "metal-pullers",
    category: "Pullers",
    subcategory: "Metal",
    name: "Metal Pullers",
    description:
      "Refined metal pullers designed to combine durability with distinctive visual detail.",
    image:
      "https://images.unsplash.com/photo-1445205170230-053b83016050?auto=format&fit=crop&w=1200&q=80",
    href: "/products/metal-pullers",
  },
  {
    id: "branded-pullers",
    category: "Pullers",
    subcategory: "Branded",
    name: "Branded Pullers",
    description:
      "Customized puller solutions designed to incorporate distinctive brand details.",
    image:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80",
    href: "/products/branded-pullers",
  },

  // =========================================
  // GARMENT ACCESSORIES — 5
  // =========================================
  {
    id: "pull-tabs",
    category: "Garment Accessories",
    subcategory: "Pull Tabs",
    name: "Pull Tabs",
    description:
      "Functional and decorative pull tab solutions for contemporary garment construction.",
    image:
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1200&q=80",
    href: "/products/pull-tabs",
  },
  {
    id: "decorative-hardware",
    category: "Garment Accessories",
    subcategory: "Hardware",
    name: "Decorative Hardware",
    description:
      "Design-led hardware components created to add distinctive finishing details to apparel.",
    image:
      "https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?auto=format&fit=crop&w=1200&q=80",
    href: "/products/decorative-hardware",
  },
  {
    id: "garment-fasteners",
    category: "Garment Accessories",
    subcategory: "Fasteners",
    name: "Garment Fasteners",
    description:
      "Reliable fastening components developed for a broad range of apparel applications.",
    image:
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1200&q=80",
    href: "/products/garment-fasteners",
  },
  {
    id: "fashion-accessories",
    category: "Garment Accessories",
    subcategory: "Fashion",
    name: "Fashion Accessories",
    description:
      "Premium accessory components designed to enhance the visual character of garments.",
    image:
      "https://images.unsplash.com/photo-1523779917675-b6ed3a42a561?auto=format&fit=crop&w=1200&q=80",
    href: "/products/fashion-accessories",
  },
  {
    id: "technical-accessories",
    category: "Garment Accessories",
    subcategory: "Technical",
    name: "Technical Accessories",
    description:
      "Performance-oriented components for specialized apparel and garment applications.",
    image:
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1200&q=80",
    href: "/products/technical-accessories",
  },

  // =========================================
  // FASTENING COMPONENTS — 5
  // =========================================
  {
    id: "zipper-components",
    category: "Fastening Components",
    subcategory: "Zipper Components",
    name: "Zipper Components",
    description:
      "Precision components supporting complete zipper systems and fastening applications.",
    image:
      "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1200&q=80",
    href: "/products/zipper-components",
  },
  {
    id: "slider-components",
    category: "Fastening Components",
    subcategory: "Slider Components",
    name: "Slider Components",
    description:
      "Specialized components designed for dependable slider performance and assembly.",
    image:
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1200&q=80",
    href: "/products/slider-components",
  },
  {
    id: "puller-components",
    category: "Fastening Components",
    subcategory: "Puller Components",
    name: "Puller Components",
    description:
      "Supporting components designed for functional and customized fastening systems.",
    image:
      "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=1200&q=80",
    href: "/products/puller-components",
  },
  {
    id: "custom-hardware",
    category: "Fastening Components",
    subcategory: "Custom Hardware",
    name: "Custom Hardware",
    description:
      "Specialized hardware solutions developed around individual product requirements.",
    image:
      "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=1200&q=80",
    href: "/products/custom-hardware",
  },
  {
    id: "specialized-components",
    category: "Fastening Components",
    subcategory: "Specialized",
    name: "Specialized Components",
    description:
      "Application-focused components developed for specialized apparel requirements.",
    image:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1200&q=80",
    href: "/products/specialized-components",
  },

  // =========================================
  // CUSTOM SOLUTIONS — 5
  // =========================================
  {
    id: "custom-zipper-development",
    category: "Custom Solutions",
    subcategory: "Zipper Development",
    name: "Custom Zipper Development",
    description:
      "Tailored zipper development built around specific garment and design requirements.",
    image:
      "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1200&q=80",
    href: "/products/custom-zipper-development",
  },
  {
    id: "custom-slider-development",
    category: "Custom Solutions",
    subcategory: "Slider Development",
    name: "Custom Slider Development",
    description:
      "Purpose-built slider solutions developed around individual product specifications.",
    image:
      "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=1200&q=80",
    href: "/products/custom-slider-development",
  },
  {
    id: "custom-puller-development",
    category: "Custom Solutions",
    subcategory: "Puller Development",
    name: "Custom Puller Development",
    description:
      "Distinctive puller concepts developed for unique brand and garment applications.",
    image:
      "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=1200&q=80",
    href: "/products/custom-puller-development",
  },
  {
    id: "branded-components",
    category: "Custom Solutions",
    subcategory: "Branding",
    name: "Branded Components",
    description:
      "Customized fastening components incorporating distinctive brand details and identity.",
    image:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80",
    href: "/products/branded-components",
  },
  {
    id: "application-specific-solutions",
    category: "Custom Solutions",
    subcategory: "Application",
    name: "Application-Specific Solutions",
    description:
      "Fastening solutions developed around the functional demands of individual applications.",
    image:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1200&q=80",
    href: "/products/application-specific-solutions",
  },
];

export default products;